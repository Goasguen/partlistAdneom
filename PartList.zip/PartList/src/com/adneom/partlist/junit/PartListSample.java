package com.adneom.partlist.junit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import org.junit.Assert;
import org.junit.Test;

import com.adneom.partlist.util.PartList;

import junit.framework.TestCase;

public class PartListSample extends TestCase {

	@Test
	public void testParams()
	{
		try {
			/** Test different type de liste**/
		    List<String> arrayOfString = new ArrayList<String>(Arrays.asList("A","B","C","D","E"));    
	        List<Integer> integerLinkedL = new LinkedList<Integer>(Arrays.asList(1,2,3,4));
		    Vector<Double> doubleVectorList = new Vector<Double>(Arrays.asList(new Double(1), new Double(2)));
		    
		    System.out.println("arrayOfString= "+arrayOfString);
		    System.out.println("integerLinkedL= "+integerLinkedL);
     	    System.out.println("doubleVectorList= "+doubleVectorList);		      	    
			System.out.println("Test arrayOfString res = "+PartList.partition(arrayOfString, 2));
			System.out.println("Test integerLinkedL res = "+PartList.partition(integerLinkedL, 2));
			System.out.println("Test doubleVectorList res = "+PartList.partition(doubleVectorList, 2));
			
			
			/** Test valeurs � 0 ou nulles **/
			 ArrayList<ArrayList<String>> expectedRes = new ArrayList<ArrayList<String>>();
			 Assert.assertArrayEquals(PartList.partition(null, 2).toArray(), expectedRes.toArray());
			 Assert.assertArrayEquals(PartList.partition(arrayOfString, null).toArray(), expectedRes.toArray());
			 Assert.assertArrayEquals(PartList.partition(arrayOfString, 0).toArray(), expectedRes.toArray());
	    
		} catch (Exception e) {
			org.junit.Assert.fail(e.getMessage());
		}

	}
	
	@Test
	public void testCases()
	{
		try {
			
			//Cas 1 taille multiple du input size
		    List<Integer> inputList = new ArrayList<Integer>(Arrays.asList(1,2,3,4)); 
		    ArrayList<ArrayList<Integer>> expectedRes = new ArrayList<ArrayList<Integer>>();
		    expectedRes.add(new ArrayList<Integer>(Arrays.asList(1,2)));
		    expectedRes.add(new ArrayList<Integer>(Arrays.asList(3,4)));
		    Assert.assertArrayEquals(PartList.partition(inputList, 2).toArray(), expectedRes.toArray());
		    
			//Cas 2 taille non multiple du input size sur plus de une iteration
		    List<Integer> inputList2 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); 
		    ArrayList<ArrayList<Integer>> expectedRes2 = new ArrayList<ArrayList<Integer>>();
		    expectedRes2.add(new ArrayList<Integer>(Arrays.asList(1,2)));
		    expectedRes2.add(new ArrayList<Integer>(Arrays.asList(3,4)));
		    expectedRes2.add(new ArrayList<Integer>(Arrays.asList(5)));
		    Assert.assertArrayEquals(PartList.partition(inputList2, 2).toArray(), expectedRes2.toArray());
		    
			//Cas 3 taille non multiple du input size sur une iteration
		    List<Integer> inputList3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); 
		    ArrayList<ArrayList<Integer>> expectedRes3 = new ArrayList<ArrayList<Integer>>();
		    expectedRes3.add(new ArrayList<Integer>(Arrays.asList(1,2,3,4)));
		    expectedRes3.add(new ArrayList<Integer>(Arrays.asList(5)));
		    Assert.assertArrayEquals(PartList.partition(inputList3, 4).toArray(), expectedRes3.toArray());
		    
			//Cas 4 inputsize < taille
		    List<Integer> inputList4 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); 
		    ArrayList<ArrayList<Integer>> expectedRes4 = new ArrayList<ArrayList<Integer>>();
		    expectedRes4.add(new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)));
		    Assert.assertArrayEquals(PartList.partition(inputList4, 7).toArray(), expectedRes4.toArray());
		    
			//Cas 5 inputsize = taille
		    List<Integer> inputList5 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6)); 
		    ArrayList<ArrayList<Integer>> expectedRes5 = new ArrayList<ArrayList<Integer>>();
		    expectedRes5.add(new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6)));
		    Assert.assertArrayEquals(PartList.partition(inputList5, 6).toArray(), expectedRes5.toArray());
		    
		    
		} catch (Exception e) {
			org.junit.Assert.fail(e.getMessage());
		}

	}
}
