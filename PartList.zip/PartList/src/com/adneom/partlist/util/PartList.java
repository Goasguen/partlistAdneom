package com.adneom.partlist.util;

import java.util.ArrayList;
import java.util.List;


public class PartList {

	/**
	 * This method divide an inputList into several list of param taille size
	 *
	 * @param liste List<T>
	 * @param taille Integer - The size of partitioned result list
	 * @return  ArrayList<ArrayList<T>>
	 * @throws Exception
	 */
	public static <T> ArrayList<ArrayList<T>> partition(List<T> liste, Integer taille) throws Exception {
		ArrayList<ArrayList<T>> result = new ArrayList<ArrayList<T>>();
		try {
			
			/** Si probl�me dans les param�tres on retourne une liste vide **/
			if (liste == null || taille == null || taille == 0) {
				return result;
			}
			
			
			int listSize = liste.size();
	
			/** Si taille de d�coupage plus importante que la taille de la liste on retourne la liste**/
			if (taille > listSize) {
				result.add(new ArrayList<T>(liste));
				return result;
			}

			for (int i = 1; i <= listSize; i++) {
				/** On a atteint le param�tre taille on decoupe la liste **/
				if (i % taille == 0) {
					result.add(new ArrayList<T>(liste.subList(i - taille, i)));
				}

			}

			/** On ajoute la derni�re liste **/
			if (listSize % taille != 0) {	
				int reste = listSize % taille;
				result.add(new ArrayList<T>(liste.subList(listSize - reste, listSize)));
			}
			return result;
		} catch (Exception e) {
			throw new Exception(e.getMessage(), e);
		}

	}
}
