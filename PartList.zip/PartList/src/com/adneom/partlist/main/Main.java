package com.adneom.partlist.main;

import java.util.ArrayList;

import com.adneom.partlist.util.PartList;

public class Main {

	public static void main(String[] args) throws Exception {
		
	ArrayList<Integer> input = new ArrayList<>();
	
	for(int i = 0; i < 19; i++)
	{	
		input.add(i);
	}
	
	System.out.println("INPUT = "+ input);
	System.out.println("RES = "+ PartList.partition(input,3));

	}
	

}
